<link rel="stylesheet" type="text/css" href="../sidebar/sidebar.css">
<div id="wrapper" class="navbar-dark">
    <div id="sidebar-wrapper">
        <div class="sidebar-nav">
            <div id="menu">
                <a href="#menu-toggle" id="menu-toggle"><span class="navbar-toggler-icon"></span></a>    
            </div>
            <div id="terms">  
            </div>
        </div>
    </div> 
</div>
<script type="text/javascript" src="../sidebar/sidebar.js"></script>
<!-- /#sidebar-wrapper -->
