</div>
<div class="background-grey">
    <div id="Footer">
        <a href="#">LingoLand, Rensselaer Polytechnic Institute </a>
        <a href="https://github.com/neptune7000/LingoLand">GitHub Repository</a>
    </div>
</div>
</body>

</html>