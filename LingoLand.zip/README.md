# LingoLand


## Using Flashcard Maker:
1. create a secret.php file inside `articleParser`
2. copy and paste the bottom code, be sure to replace `<apikey>` with the actual api key.
``` php
<?php
    $password = "<apikey>";
?>
```
3. Start xammp and go to the articleParser.php page (linked in the navigation bar as flashcard maker)